# Dependencies and Auto-install Policy

Auto-install behavior depends on gate type:

- **Config-gated**: installs only when project config/deps indicate usage (a `config-first` row in `TOOL_EXECUTION_POLICY`; `tests/config/gate-table-derived.test.ts` pins this)
- **Flow/language-gated**: installs when the runtime path needs it for the current file/session flow
- **Operational prewarm**: installs during session warm scans / turn-end analysis paths
- **GitHub release**: platform-specific binary downloaded from GitHub releases to `~/.pi-lens/bin/`

| Tool                                | Purpose                          | Auto-installed | Gate                               |
| ----------------------------------- | -------------------------------- | -------------- | ---------------------------------- |
| `@biomejs/biome`                    | JS/TS lint/format/autofix        | Yes            | Language-default                                         |
| `prettier`                          | Formatting fallback              | Yes            | Language-default for `.less`, `.graphql`, `.gql`; other types need prettier config |
| `yamllint`                          | YAML linting                     | Yes            | Language-default                                         |
| `actionlint`                        | GitHub Actions workflow linting  | Yes            | GitHub release                     |
| `sqlfluff`                          | SQL linting/formatting           | Yes            | Language-default                                         |
| `ruff`                              | Python lint/format/autofix       | Yes            | Language-default + flow-gated      |
| `typescript-language-server`        | Unified LSP diagnostics          | Yes            | Language-default                   |
| `typescript`                        | TypeScript compiler              | Yes            | Language-default                   |
| `pyright`                           | Python type diagnostics fallback | Yes            | Flow/language-gated                |
| `@ast-grep/cli` (sg)                | AST scans/search/replace         | Yes            | Operational prewarm                |
| `knip`                              | Dead code analysis               | Yes            | Operational prewarm                |
| `jscpd`                             | Duplicate code detection         | Yes            | Operational prewarm                |
| `madge`                             | Circular dependency analysis     | Yes            | Turn-end analysis flow             |
| `mypy`                              | Python type checking             | Yes            | Flow-gated                         |
| `stylelint`                         | CSS/SCSS/Less linting            | Yes            | Language-default                                         |
| `markdownlint-cli2`                 | Markdown linting                 | Yes            | Language-default                                         |
| `shellcheck`                        | Shell script linting             | Yes            | GitHub release                     |
| `shfmt`                             | Shell script formatting          | Yes            | GitHub release                     |
| `rust-analyzer`                     | Rust LSP                         | Yes            | GitHub release                     |
| `lake serve`                        | Lean 4 LSP                       | No             | `lake` must be on PATH; uses the project's Lean toolchain |
| `golangci-lint`                     | Go linting                       | Yes            | GitHub release                     |
| `hadolint`                          | Dockerfile linting               | Yes            | GitHub release                     |
| `ktlint`                            | Kotlin linting                   | Yes            | GitHub release                     |
| `tflint`                            | Terraform linting                | Yes            | GitHub release                     |
| `taplo`                             | TOML linting/formatting          | Yes            | GitHub release                     |
| `terraform-ls`                      | Terraform LSP                    | Yes            | GitHub release                     |
| `htmlhint`                          | HTML linting                     | Yes            | Language-default                                         |
| `@prisma/language-server`           | Prisma LSP                       | Yes            | Flow-gated                         |
| `dockerfile-language-server-nodejs` | Dockerfile LSP                   | Yes            | Flow-gated                         |
| `intelephense`                      | PHP LSP                          | Yes            | Flow-gated                         |
| `bash-language-server`              | Bash LSP                         | Yes            | Language-default                   |
| `yaml-language-server`              | YAML LSP                         | Yes            | Language-default                   |
| `vscode-json-language-server`       | JSON LSP (`vscode-langservers-extracted`) | Yes  | Language-default                   |
| `vscode-css-languageserver`         | CSS LSP (`vscode-langservers-extracted`)  | Yes  | Language-default                   |
| `vscode-html-languageserver-bin`    | HTML LSP (`vscode-langservers-extracted`) | Yes  | Language-default                   |
| `svelte-language-server`            | Svelte LSP                       | Yes            | Flow-gated                         |
| `@vue/language-server`              | Vue LSP                          | Yes            | Flow-gated                         |
| `opengrep`                          | Experimental security dispatch   | Auto-install   | Local config / explicit opt-in     |
| `gitleaks`                          | Committed-secret session scan    | Auto-install   | Opt-in (config / hook / dep)       |
| `govulncheck`                       | Go reachable-CVE session scan    | `go install`   | Auto (`go.mod` present)            |
| `trivy`                             | Dependency-CVE session scan      | Auto-install   | Explicit opt-in (`trivy.enabled`)  |
| `fallow-lsp`                        | JS/TS unused-code, duplication and cycle advisories | Auto-install | Explicit opt-in (`fallow.enabled`, pinned GitHub release) |
| `psscriptanalyzer`                  | PowerShell linting               | Manual         | —                                  |

Lean LSP is launched as `lake serve` from the detected Lake project root, so elan selects the toolchain from that project's `lean-toolchain` file and Lake supplies its project environment. pi-lens does not install or manage Lean/elan; install Lean and Lake separately and ensure `lake` is on `PATH`.

Additional language servers (gopls, ruby-lsp, solargraph, etc.) are auto-detected from PATH or installed via native package managers (`go install`, `gem install`) when their language is detected.

## Pip tool installation order

For pip-backed tools, pi-lens uses this order:

1. Use `pipx install` when `pipx` is available.
2. Create or reuse `<PI_LENS_HOME>/pip-tools` with `python3 -m venv`, then use that venv's `pip`.
3. Use `pip install --user` when the interpreter accepts a normal user install.
4. If PEP 668 refuses the user install, use `--user --break-system-packages` only with `PYTHONUSERBASE` set to the pi-lens-private `<PI_LENS_HOME>/pip-user` prefix.

Pi-lens never passes `--break-system-packages` to a system prefix. It adds the selected pipx, venv, or private-prefix `bin`/`Scripts` directory to the current process path so the availability probe resolves the installed tool.
