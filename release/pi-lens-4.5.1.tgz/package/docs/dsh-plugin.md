# DeepSeek Harness plugin

pi-lens ships a native DeepSeek Harness (DSH) adapter. The same npm package is
both a pi extension and a DSH plugin: pi loads `dist/index.js`, DSH loads the
Cordis entry declared in `package.json#dsh` and described by
[`cordis.patch.yml`](../cordis.patch.yml).

| Item                    | Value                                                      |
| ----------------------- | ---------------------------------------------------------- |
| DSH plugin standard     | 2.0.0 (adopted 2026-08-19)                                 |
| Plugin shape            | host plane, `apply(ctx)` + `inject` + Schemastery `Config` |
| Service dependency      | `tools`                                                    |
| Transport to the engine | MCP over stdio (newline-delimited JSON-RPC 2.0)            |
| Compliance gate         | `node scripts/verify-plugin.mjs .` → **0 MUST violations** |
| Package entry           | `pi-lens` → `dist/dsh/index.js` (`exports["./dsh"]`)       |

## Architecture

```text
DSH host (Cordis)
  └─ pi-lens plugin (dist/dsh/index.js)
       ├─ ctx.tools.register(pilens_status)      always available
       ├─ ctx.tools.register(pilens_*)           discovered from tools/list
       └─ McpStdioClient ──stdio JSON-RPC──▶ pi-lens-mcp (dist/mcp/server.js)
```

The adapter does not re-implement analysis. It owns one long-lived
`pi-lens-mcp` child and projects each MCP capability onto a DSH tool, so the
tool catalog follows the engine, including tools added in later releases.

## Install

```bash
dsh plugin --profile tui add pi-lens
```

The profile name (`tui`, `web`, `headless`, or your own) is required; `dsh`
forwards the remaining arguments to pnpm in that profile's directory. `dsh`
reads `package.json#dsh.bundle.patch`, applies the bundle patch, and mounts the
row. To pin an exact version:

```bash
dsh plugin --profile tui add pi-lens@4.5.1
```

If your profile is assembled by hand, add the bundle patch or the row directly
to the profile's `cordis.patch.yml`:

```yaml
- insert:
    - id: pi-lens
      name: pi-lens
```

The package root resolves to the DSH entry (`dist/dsh/index.js`). The pi
extension stays at the `./pi` subpath and `package.json#pi.extensions`, so the
harness never imports pi host packages such as `@earendil-works/pi-tui`.

From a local tarball, pass an absolute path because pnpm runs inside the
profile directory:

```bash
dsh plugin --profile tui add /absolute/path/to/pi-lens-4.5.1.tgz
```

The packaged entry is verified against DSH `0.0.1-rc.1` and `0.2.2-rc.1`.
With `dsh` `0.2.2-rc.1`, `plugin add` resolves the tarball, writes it to
`dsh.profile.bundles`, and `dsh --dump-config` shows the composed `pi-lens`
row.

## Configuration

Defaults come from the Schemastery schema in
[`dsh/src/plugin.ts`](../dsh/src/plugin.ts). Override any subset with a later
patch row addressed by the row id `pi-lens`:

```yaml
- update:
    - id: pi-lens
      config:
        requestTimeoutMs: 180000
        includeTools:
          - pilens_diagnostics
          - pilens_navigate
```

| Key                | Default  | Meaning                                                                  |
| ------------------ | -------- | ------------------------------------------------------------------------ |
| `enabled`          | `true`   | Load the adapter. `false` registers nothing.                             |
| `serverPath`       | `""`     | Override the MCP entry. Empty resolves the bundled `dist/mcp/server.js`. |
| `cwd`              | `""`     | Workspace handed to the engine. Empty uses the host cwd.                 |
| `startupTimeoutMs` | `15000`  | Handshake budget for `initialize`.                                       |
| `requestTimeoutMs` | `120000` | Per-call budget; also the registered DSH tool timeout.                   |
| `includeTools`     | `[]`     | Empty includes every advertised tool.                                    |
| `excludeTools`     | `[]`     | Names always dropped.                                                    |
| `restartOnCrash`   | `true`   | Restart the engine after an unexpected exit.                             |
| `maxRestarts`      | `3`      | Consecutive restart budget before staying degraded.                      |
| `restartBackoffMs` | `500`    | Exponential backoff base, capped at 30 s.                                |
| `maxTextChars`     | `120000` | Truncation bound for tool result text.                                   |
| `env`              | `{}`     | Extra environment variables forwarded to the child.                      |
| `debug`            | `false`  | Write adapter diagnostics to stderr.                                     |

Only a minimal environment is forwarded to the child: `PATH`, `HOME`,
`TMPDIR`/`TEMP`, locale, and Windows shell variables. Credentials are not
inherited; pass what the engine needs explicitly through `env`.

## Capabilities

`pilens_status` is always registered. It reports lifecycle phase, engine state,
MCP protocol version, pid, tool count, restart count, and the last error.

Every tool returned by MCP `tools/list` is registered under its original name
(the `pilens_` namespace) unless filtered out. The harness-reserved name
`run_code` is never proxied. Because the catalog is dynamic, new pi-lens tools
work in DSH without an adapter release.

MCP schemas are projected onto the JSON Schema subset DSH enforces. Supported
keywords (`type`, `properties`, `required`, `items`, `enum`, `const`,
`oneOf`, annotations) are preserved; unsupported keywords (`format`,
`minimum`, `anyOf`, …) are dropped rather than silently forwarded, and the MCP
server remains the argument validator. Mutating tools stay concurrency-unsafe;
only tools with `readOnlyHint: true` opt into concurrent execution.

## Lifecycle and cleanup

| Phase   | Adapter action                                                                                                                      |
| ------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| Load    | Cordis evaluates `inject = ["tools"]`; `Config` is validated.                                                                       |
| Init    | `apply` enters an `ctx.effect` scope, registers `pilens_status`, starts the MCP handshake.                                          |
| Enable  | `ACTIVE`; discovered tools are registered. A failed engine start degrades to `DEGRADED` without failing the host.                   |
| Disable | `ctx.effect` disposer rejects in-flight calls, sends `SIGTERM`, escalates to `SIGKILL` after 2 s, disposes every tool registration. |
| Unload  | `DISPOSED`; no timers, listeners, or child processes remain.                                                                        |

The adapter exposes the same states in `pilens_status`. Restarts are bounded:
unexpected exits use exponential backoff and stop after `maxRestarts`
consecutive failures, keeping the host interactive (fail-soft).

## Communication protocol

- MCP `initialize` → `notifications/initialized` handshake, then `tools/list`
  and `tools/call`.
- JSON-RPC 2.0 frames are newline-delimited. A single stdout chunk may contain
  partial frames, several frames, or both.
- DSH cancellation (`exec.signal`) sends MCP `notifications/cancelled` and
  rejects the pending request; the client stays usable.
- Request timeouts reject the pending call without corrupting the stream.
- The child is spawned without a shell and always through the host Node binary;
  arguments are fixed and never string-interpolated.

## Verification

```bash
npm run build:dsh     # compile dist/dsh
npm run test:dsh      # 21 contract tests + optional real-host test
npm run verify:dsh    # DSH plugin standard compliance gate
npm run verify        # build + tests + compliance
npm run pack:check    # inspect the publish manifest
```

The compatibility suite covers:

- manifest, patch, exports, peer-dependency and capability declarations;
- MCP framing, handshake, pagination, tool errors, cancellation, and timeouts;
- schema projection for the enforced DSH subset, including adversarial depth;
- lifecycle registration, filtering, unload cleanup, and degraded behavior;
- a performance budget over a 500-tool catalog and 25 concurrent calls.

When `@deepseek-ai/cordis`, `@deepseek-ai/dsh-system-prompt`, and
`@deepseek-ai/dsh-tools` resolve, `dsh/tests/host.test.mjs` additionally loads
the packaged entry into a real Cordis `ToolRegistry`, executes tools through the
host pipeline, and verifies unload removes them. In a plain checkout it reports
as skipped; the contract suite still runs.

### Documented deviation

The standard's `files` recommendation (§2.1.9, SHOULD) expects a `lib/`
directory. pi-lens compiles to `dist/`, which already contains the published
entries and is listed in `files`; `verify-plugin` therefore reports that single
WARN and no FAIL. Adding an empty `lib/` would misrepresent the build layout.

## Troubleshooting

- **`pilens_status` reports `engine: degraded`** — inspect `lastError`; set
  `debug: true` for stderr diagnostics. The bundled engine path is
  `dist/mcp/server.js`; if you moved the install, set `serverPath`.
- **No `pilens_*` tools besides `pilens_status`** — the handshake failed or
  `includeTools` filtered everything. Empty `includeTools` means “all”.
- **Tool calls time out** — large workspaces may need a higher
  `requestTimeoutMs`. Cancellation leaves the adapter usable.
- **Restart budget exhausted** — after `maxRestarts` consecutive crashes the
  adapter stays degraded instead of crash-looping. Fix the engine failure and
  reload the plugin.
- **`ERR_MODULE_NOT_FOUND: @earendil-works/pi-tui` on activation** — the
  profile is loading an old package root that still points at the pi extension.
  Reinstall the packaged release; its root export is `dist/dsh/index.js`, while
  the pi entry lives at `dist/index.js` and `./pi`. Do not point a row at an
  extracted folder's `dist/index.js`.

## Compatibility with pi

The DSH adapter is additive. `pi` continues to load `dist/index.js` through
`package.json#pi.extensions` and `exports["./pi"]`; the DSH root export, patch,
and manifests are not on pi's load path.
