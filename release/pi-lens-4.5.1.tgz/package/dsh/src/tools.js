/**
 * DSH `ToolDefinition` projection for pi-lens MCP tools.
 *
 * Every capability the engine advertises on `tools/list` becomes a native DSH
 * tool: the MCP schema is sanitized into the enforced DSH subset, execution
 * forwards cancellation, and the canonical value carries compact text so the
 * tool result is stable and replayable (DSH standard §3.4).
 */
import { renderMcpResult, toParameterSchema } from "./schema.js";
const OUTPUT_SCHEMA = {
    type: "object",
    properties: {
        text: { type: "string" },
        isError: { type: "boolean" },
    },
    required: ["text"],
    additionalProperties: false,
};
/** Tool names reserved by the harness itself and therefore never proxied. */
const RESERVED_TOOL_NAMES = new Set(["run_code"]);
export function isProjectableTool(tool, include, exclude) {
    if (RESERVED_TOOL_NAMES.has(tool.name))
        return false;
    if (!/^[A-Za-z_][A-Za-z0-9_-]*$/.test(tool.name))
        return false;
    if (exclude.includes(tool.name))
        return false;
    return include.length === 0 || include.includes(tool.name);
}
export function projectTool(tool, options) {
    const description = buildDescription(tool);
    const definition = {
        name: tool.name,
        description,
        parameters: toParameterSchema(tool.inputSchema),
        output: {
            schema: OUTPUT_SCHEMA,
            render(_args, value) {
                const canonical = value;
                return [{ type: "text", text: canonical.text }];
            },
        },
        timeoutMs: options.requestTimeoutMs,
        async execute(args, exec) {
            const result = await options.caller.callTool(tool.name, asArguments(args), exec.signal);
            const text = renderMcpResult(result, options.maxTextChars);
            if (result.isError === true) {
                options.onError?.(`${tool.name}: ${text}`);
                throw new Error(text);
            }
            return { text, isError: false };
        },
    };
    // Only explicitly read-only MCP tools may run concurrently; mutating tools
    // (autofix, rename, format) inherit the harness's strict default.
    if (tool.annotations?.readOnlyHint === true) {
        definition.isConcurrencySafe = () => true;
    }
    return definition;
}
function asArguments(args) {
    if (typeof args !== "object" || args === null || Array.isArray(args))
        return {};
    return { ...args };
}
function buildDescription(tool) {
    const base = typeof tool.description === "string" && tool.description.trim().length > 0
        ? tool.description.trim()
        : `Run the pi-lens ${tool.name} capability.`;
    if (base.includes("Side effects:"))
        return base;
    return [
        base,
        "Call when language-aware feedback or code navigation is needed for the current workspace.",
        "Preconditions: the plugin is loaded and the pi-lens engine has completed its MCP handshake.",
        "Returns compact text from the MCP server; failures surface as tool errors.",
        "Side effects: read-only analysis; language servers or linters may be started on demand.",
    ].join("\n");
}
