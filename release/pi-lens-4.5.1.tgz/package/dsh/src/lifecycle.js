/**
 * Explicit plugin lifecycle model.
 *
 * Cordis owns the authoritative fiber state; this class mirrors the phase
 * transitions the adapter performs so `pilens_status` and the compatibility
 * tests can assert load → init → enable → disable → unload without reading
 * framework internals.
 */
const ALLOWED = {
    PENDING: ["LOADING", "FAILED"],
    LOADING: ["ACTIVE", "DEGRADED", "FAILED", "UNLOADING"],
    ACTIVE: ["DEGRADED", "UNLOADING", "FAILED"],
    DEGRADED: ["ACTIVE", "UNLOADING", "FAILED"],
    FAILED: ["UNLOADING", "DISPOSED"],
    UNLOADING: ["DISPOSED"],
    DISPOSED: [],
};
export class PluginLifecycle {
    current = "PENDING";
    transitions = [];
    listeners = new Set();
    get state() {
        return this.current;
    }
    get history() {
        return this.transitions;
    }
    /** Move to `next`, rejecting transitions that would skip cleanup phases. */
    transition(next) {
        if (next === this.current) {
            return { from: this.current, to: next, at: Date.now() };
        }
        if (!ALLOWED[this.current].includes(next)) {
            throw new Error(`Illegal plugin lifecycle transition ${this.current} -> ${next}`);
        }
        const transition = {
            from: this.current,
            to: next,
            at: Date.now(),
        };
        this.current = next;
        this.transitions.push(transition);
        for (const listener of this.listeners)
            listener(transition);
        return transition;
    }
    onTransition(listener) {
        this.listeners.add(listener);
        return () => {
            this.listeners.delete(listener);
        };
    }
}
