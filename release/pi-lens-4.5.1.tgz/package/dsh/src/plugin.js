/**
 * pi-lens DSH plugin entry.
 *
 * DSH (DeepSeek Harness) loads Cordis plugins through `apply(ctx, config)`.
 * This module is the host-plane adapter:
 *
 * - `name`      Cordis plugin id
 * - `inject`    waits for the `tools` service before activation
 * - `Config`    Schemastery schema with defaults (validated before apply)
 * - `apply`     owns every resource through `ctx.effect`/`ctx.tools.register`
 *
 * The adapter proxies the engine's MCP server instead of duplicating analysis
 * logic, so every pi-lens capability listed on `tools/list` is exposed as a
 * native DSH tool.
 */
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import Schema from "@deepseek-ai/schemastery";
import { PluginLifecycle } from "./lifecycle.js";
import { buildChildEnv, McpStdioClient, } from "./mcp-client.js";
import { isProjectableTool, projectTool, } from "./tools.js";
export const name = "pi-lens";
export const inject = ["tools"];
/** Adapter version reported in the MCP `clientInfo` handshake. */
export const adapterVersion = "1.0.0";
const MAX_RESTART_BACKOFF_MS = 30_000;
export const Config = Schema.object({
    enabled: Schema.boolean().default(true),
    serverPath: Schema.string().default(""),
    cwd: Schema.string().default(""),
    startupTimeoutMs: Schema.natural().default(15_000),
    requestTimeoutMs: Schema.natural().default(120_000),
    includeTools: Schema.array(String).default([]),
    excludeTools: Schema.array(String).default([]),
    restartOnCrash: Schema.boolean().default(true),
    maxRestarts: Schema.natural().default(3),
    restartBackoffMs: Schema.natural().default(500),
    maxTextChars: Schema.natural().default(120_000),
    env: Schema.dict(String).default({}),
    debug: Schema.boolean().default(false),
});
class PiLensRuntime {
    config;
    lifecycle;
    serverPath;
    workspace;
    client = null;
    state = "idle";
    startPromise = null;
    restartTimer = null;
    failures = 0;
    restarts = 0;
    lastError;
    disposed = false;
    tools = [];
    onTools;
    constructor(config, lifecycle, serverPath, workspace) {
        this.config = config;
        this.lifecycle = lifecycle;
        this.serverPath = serverPath;
        this.workspace = workspace;
    }
    async start() {
        if (this.disposed)
            throw new Error("pi-lens runtime is disposed");
        if (this.client?.state === "ready")
            return;
        if (this.startPromise)
            return this.startPromise;
        this.startPromise = this.startInternal().finally(() => {
            this.startPromise = null;
        });
        return this.startPromise;
    }
    async startInternal() {
        if (this.disposed)
            throw new Error("pi-lens runtime is disposed");
        this.state = "starting";
        const client = new McpStdioClient({
            args: [this.serverPath, `--cwd=${this.workspace}`],
            cwd: this.workspace,
            env: buildChildEnv(this.config.env),
            startupTimeoutMs: this.config.startupTimeoutMs,
            requestTimeoutMs: this.config.requestTimeoutMs,
            clientName: "dsh-pi-lens",
            clientVersion: adapterVersion,
            logger: (level, message) => this.log(level, message),
            onExit: (code, signal) => {
                if (this.client === client)
                    this.handleUnexpectedExit(code, signal);
            },
        });
        this.client = client;
        try {
            await client.start();
            const tools = await client.listTools();
            if (this.disposed) {
                await client.dispose();
                return;
            }
            this.tools = tools;
            this.state = "ready";
            this.failures = 0;
            this.lastError = undefined;
            this.onTools?.(tools);
            if (this.lifecycle.state === "DEGRADED")
                this.lifecycle.transition("ACTIVE");
            this.log("info", `engine ready (${tools.length} tools, pid=${client.pid ?? "?"})`);
        }
        catch (error) {
            this.state = "degraded";
            this.lastError = errorMessage(error);
            if (this.lifecycle.state === "ACTIVE")
                this.lifecycle.transition("DEGRADED");
            await client.dispose();
            this.scheduleRestart();
            throw error;
        }
    }
    async callTool(toolName, args, signal) {
        if (signal?.aborted)
            throw new Error(`MCP call '${toolName}' aborted`);
        if (this.disposed)
            throw new Error("pi-lens runtime is disposed");
        if (this.client?.state !== "ready")
            await this.start();
        const client = this.client;
        if (!client || client.state !== "ready") {
            throw new Error(`pi-lens engine is unavailable (${this.state}${this.lastError ? `: ${this.lastError}` : ""})`);
        }
        return client.callTool(toolName, args, signal);
    }
    status() {
        return {
            lifecycle: this.lifecycle.state,
            engine: this.state,
            pid: this.client?.pid,
            server: this.serverPath,
            cwd: this.workspace,
            protocolVersion: this.client?.serverInfo.protocolVersion,
            serverName: this.client?.serverInfo.serverInfo?.name,
            tools: this.tools.length,
            restarts: this.restarts,
            lastError: this.lastError,
            stderr: this.client?.stderr ?? [],
        };
    }
    async dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        this.state = "disposed";
        if (this.restartTimer) {
            clearTimeout(this.restartTimer);
            this.restartTimer = null;
        }
        const client = this.client;
        this.client = null;
        this.onTools = undefined;
        if (client)
            await client.dispose();
    }
    handleUnexpectedExit(code, signal) {
        if (this.disposed)
            return;
        this.state = "degraded";
        this.lastError = `engine exited (code=${code ?? "null"}, signal=${signal ?? "none"})`;
        this.log("warn", this.lastError);
        if (this.lifecycle.state === "ACTIVE")
            this.lifecycle.transition("DEGRADED");
        this.scheduleRestart();
    }
    scheduleRestart() {
        if (this.disposed ||
            !this.config.restartOnCrash ||
            this.restartTimer !== null) {
            return;
        }
        if (this.failures >= this.config.maxRestarts) {
            this.log("warn", `restart budget exhausted (${this.failures}/${this.config.maxRestarts})`);
            return;
        }
        this.failures += 1;
        this.restarts += 1;
        const delay = Math.min(this.config.restartBackoffMs * 2 ** (this.failures - 1), MAX_RESTART_BACKOFF_MS);
        this.log("info", `restarting engine in ${delay}ms (attempt ${this.failures})`);
        this.restartTimer = setTimeout(() => {
            this.restartTimer = null;
            void this.start().catch((error) => {
                this.log("warn", `restart failed: ${errorMessage(error)}`);
            });
        }, delay);
        this.restartTimer.unref?.();
    }
    log(level, message) {
        if (!this.config.debug && level !== "error")
            return;
        process.stderr.write(`[pi-lens:${level}] ${message}\n`);
    }
}
/** Resolve the bundled `dist/mcp/server.js` relative to this module. */
export function resolveServerPath(config) {
    if (config.serverPath.trim().length > 0)
        return path.resolve(config.serverPath);
    return fileURLToPath(new URL("../mcp/server.js", import.meta.url));
}
/** Resolve the workspace handed to the engine. */
export function resolveWorkspace(config) {
    return config.cwd.trim().length > 0
        ? path.resolve(config.cwd)
        : process.cwd();
}
function createStatusTool(runtime) {
    return {
        name: "pilens_status",
        description: [
            "Report pi-lens engine health: lifecycle phase, MCP handshake state, tool count, restarts, and last error.",
            "Call when a pi-lens tool failed or before relying on analysis results.",
            "Returns compact text; read-only and side-effect free.",
        ].join("\n"),
        parameters: { type: "object", properties: {}, additionalProperties: false },
        output: {
            schema: {
                type: "object",
                properties: { text: { type: "string" } },
                required: ["text"],
                additionalProperties: false,
            },
            render(_args, value) {
                return [{ type: "text", text: value.text }];
            },
        },
        async execute() {
            return { text: renderStatus(runtime.status()) };
        },
    };
}
function renderStatus(status) {
    const lines = [
        "pi-lens DSH adapter",
        `lifecycle: ${status.lifecycle}`,
        `engine: ${status.engine}`,
        `protocol: ${status.protocolVersion ?? "unknown"}`,
        `tools: ${status.tools}`,
        `restarts: ${status.restarts}`,
        `server: ${status.server}`,
        `cwd: ${status.cwd}`,
    ];
    if (status.pid !== undefined)
        lines.push(`pid: ${status.pid}`);
    if (status.lastError)
        lines.push(`lastError: ${status.lastError}`);
    if (status.stderr.length > 0) {
        lines.push(`stderr: ${status.stderr.slice(-3).join(" | ")}`);
    }
    return lines.join("\n");
}
export function apply(ctx, config) {
    const lifecycle = new PluginLifecycle();
    lifecycle.transition("LOADING");
    if (!config.enabled) {
        lifecycle.transition("ACTIVE");
        return;
    }
    ctx.effect(() => {
        const disposers = [];
        const runtime = new PiLensRuntime(config, lifecycle, resolveServerPath(config), resolveWorkspace(config));
        const register = (definition) => {
            try {
                const dispose = ctx.tools.register(definition);
                if (typeof dispose === "function")
                    disposers.push(dispose);
            }
            catch (error) {
                process.stderr.write(`[pi-lens:error] failed to register ${definition.name}: ${errorMessage(error)}\n`);
            }
        };
        const registered = new Set();
        runtime.onTools = (tools) => {
            for (const tool of tools) {
                if (registered.has(tool.name))
                    continue;
                if (!isProjectableTool(tool, config.includeTools, config.excludeTools)) {
                    continue;
                }
                register(projectTool(tool, {
                    requestTimeoutMs: config.requestTimeoutMs,
                    maxTextChars: config.maxTextChars,
                    caller: runtime,
                }));
                registered.add(tool.name);
            }
        };
        register(createStatusTool(runtime));
        lifecycle.transition("ACTIVE");
        void runtime.start().catch((error) => {
            process.stderr.write(`[pi-lens:error] engine start failed: ${errorMessage(error)}\n`);
        });
        return async () => {
            if (lifecycle.state !== "UNLOADING" && lifecycle.state !== "DISPOSED") {
                lifecycle.transition("UNLOADING");
            }
            await runtime.dispose();
            for (const dispose of disposers.reverse()) {
                try {
                    dispose();
                }
                catch {
                    /* the host may already have unregistered this tool */
                }
            }
            if (lifecycle.state === "UNLOADING")
                lifecycle.transition("DISPOSED");
        };
    }, "pi-lens-mcp-engine");
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
